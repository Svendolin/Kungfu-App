<!-- "bluter" HTML Code in einem PHP-Dokument -->
<!-- Man beachte: es braucht hier nirgends PHP-Tags!!! -->
<footer>
<hr>
<p>Das ist Inhalt aus dem Footer</p>
<hr>
</footer>