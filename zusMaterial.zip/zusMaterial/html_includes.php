<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8" />
	<title>Kann man HTM Includes machen?</title>
</head>
<body>
<h1>Kann man HTM Includes machen?</h1>
<p>Nein, kann man nicht - oder doch?</p>
<p>Das wäre doch sehr praktisch, v.a. für immer wiederkehrende Elemente wie zum Beispiel einen Footer</p>
<?php
// Hier macht übrigens include Sinn!
include("html_includes_footer.php");
?>
</body>
</html>
